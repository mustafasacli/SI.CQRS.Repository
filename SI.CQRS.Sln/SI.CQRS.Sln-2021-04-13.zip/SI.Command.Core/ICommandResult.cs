﻿namespace SI.Command.Core
{
    public interface ICommandResult
    {
    }
}