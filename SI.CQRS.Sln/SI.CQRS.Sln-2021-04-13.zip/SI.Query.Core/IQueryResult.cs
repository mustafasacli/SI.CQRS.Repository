﻿namespace SI.Query.Core
{
    public interface IQueryResult
    { }
}