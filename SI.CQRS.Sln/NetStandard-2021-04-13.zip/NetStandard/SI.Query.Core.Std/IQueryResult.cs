﻿namespace SI.Query.Core.Std
{
    /// <summary>
    /// Defines the <see cref="IQueryResult" />.
    /// </summary>
    public interface IQueryResult
    {
    }
}
