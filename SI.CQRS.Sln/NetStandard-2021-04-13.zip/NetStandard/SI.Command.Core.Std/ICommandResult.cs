﻿namespace SI.Command.Core.Std
{
    /// <summary>
    /// Defines the <see cref="ICommandResult" />.
    /// </summary>
    public interface ICommandResult
    {
    }
}
