﻿namespace SI.Command.Core
{
    /// <summary>
    /// Defines the <see cref="ICommandResult" />.
    /// </summary>
    public interface ICommandResult
    {
    }
}
