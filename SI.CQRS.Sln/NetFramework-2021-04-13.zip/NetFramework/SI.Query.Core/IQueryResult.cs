﻿namespace SI.Query.Core
{
    /// <summary>
    /// Defines the <see cref="IQueryResult" />.
    /// </summary>
    public interface IQueryResult
    {
    }
}
